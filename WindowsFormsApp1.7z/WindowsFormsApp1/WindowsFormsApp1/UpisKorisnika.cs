﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using WindowsFormsApp1;

namespace AplikacijaBiblioteka
{
    public partial class Form1 : Form
    {
        List<Korisnici> userList = new List<Korisnici>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "bibliotekaUser.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);



        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Korisnici user = new Korisnici(Convert.ToInt32(txtUpisKorisnikId.Text), txtUpisKorisnikIme.Text, txtUpisKorisnikPrezime.Text);
            userList.Add(user);
            try
            {
                var Korisnici = XDocument.Load(path);
                foreach (Korisnici upisUXml in user)
                {
                    var Korisnik = new XElement("Korisnik",
                        new XElement("ID", upisUXml.OIB1),
                        new XElement("Ime", upisUXml.Ime1),
                        new XElement("Prezime", upisUXml.Prezime));
                    Korisnici.Root.Add(Korisnik);

                }
                Korisnici.Save(path);
            }
            catch (Exception ex)
            {
                var Korisnici = new XDocument();
                Korisnici.Add(new XElement("Korisnici"));
                foreach (Korisnici korisnik in userList)
                {
                    var Korisnik = new XElement("Korisnik",
                    new XElement("ID", korisnik.OIB1),
                    new XElement("Ime", korisnik.Ime1),
                    new XElement("Prezime", korisnik.Prezime));
                    Korisnici.Root.Add(Korisnik);
                }

                Korisnici.Save(path);

            }
            userList.Clear();
            this.Close();

            txtUpisKorisnikId.Text = "";
            txtUpisKorisnikIme.Text = "";
            txtUpisKorisnikPrezime.Text = "";
        }
    }
}

    