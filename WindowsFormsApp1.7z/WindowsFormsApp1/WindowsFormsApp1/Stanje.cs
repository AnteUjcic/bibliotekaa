﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Stanje
    {
        int OSBN,kolicine;

        public Stanje(int oSBN, int kolicine)
        {
            OSBN = oSBN;
            this.kolicine = kolicine;
        }

        public int OSBN1 { get => OSBN; set => OSBN = value; }
        public int Kolicine { get => kolicine; set => kolicine = value; }
    }
}
