﻿namespace WindowsFormsApp1
{
    partial class UpisStanja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStanjeKnjigeId = new System.Windows.Forms.TextBox();
            this.txtStanjeKnjigeKolicine = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnStanjeKnjige = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtStanjeKnjigeId);
            this.groupBox2.Controls.Add(this.txtStanjeKnjigeKolicine);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnStanjeKnjige);
            this.groupBox2.Location = new System.Drawing.Point(226, 114);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(228, 126);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stanje knjige";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "ID_knjige";
            // 
            // txtStanjeKnjigeId
            // 
            this.txtStanjeKnjigeId.Location = new System.Drawing.Point(8, 55);
            this.txtStanjeKnjigeId.Name = "txtStanjeKnjigeId";
            this.txtStanjeKnjigeId.Size = new System.Drawing.Size(100, 20);
            this.txtStanjeKnjigeId.TabIndex = 9;
            this.txtStanjeKnjigeId.TextChanged += new System.EventHandler(this.txtStanjeKnjigeId_TextChanged);
            // 
            // txtStanjeKnjigeKolicine
            // 
            this.txtStanjeKnjigeKolicine.Location = new System.Drawing.Point(8, 99);
            this.txtStanjeKnjigeKolicine.Name = "txtStanjeKnjigeKolicine";
            this.txtStanjeKnjigeKolicine.Size = new System.Drawing.Size(100, 20);
            this.txtStanjeKnjigeKolicine.TabIndex = 11;
            this.txtStanjeKnjigeKolicine.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Kolicine";
            // 
            // btnStanjeKnjige
            // 
            this.btnStanjeKnjige.Location = new System.Drawing.Point(127, 55);
            this.btnStanjeKnjige.Name = "btnStanjeKnjige";
            this.btnStanjeKnjige.Size = new System.Drawing.Size(101, 64);
            this.btnStanjeKnjige.TabIndex = 12;
            this.btnStanjeKnjige.Text = "Upis";
            this.btnStanjeKnjige.UseVisualStyleBackColor = true;
            this.btnStanjeKnjige.Click += new System.EventHandler(this.btnStanjeKnjige_Click);
            // 
            // UpisStanja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Name = "UpisStanja";
            this.Text = "UpisStanja";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtStanjeKnjigeId;
        private System.Windows.Forms.TextBox txtStanjeKnjigeKolicine;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnStanjeKnjige;
    }
}