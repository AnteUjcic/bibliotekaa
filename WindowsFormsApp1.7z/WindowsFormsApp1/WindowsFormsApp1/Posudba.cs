﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Posudba
    {
        DateTime DatumPosudbe, datumVracanja;

        public Posudba(DateTime datumPosudbe, DateTime datumVracanja)
        {
            DatumPosudbe = datumPosudbe;
            this.datumVracanja = datumVracanja;
        }

        public DateTime DatumPosudbe1 { get => DatumPosudbe; set => DatumPosudbe = value; }
        public DateTime DatumVracanja { get => datumVracanja; set => datumVracanja = value; }
    }
}
